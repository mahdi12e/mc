import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, r as Slot, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { C as Vector3, S as Vector2, _ as Path, a as Edges, b as SphereGeometry, c as Box3, f as CatmullRomCurve3, g as LatheGeometry, h as ExtrudeGeometry, i as TransformControls, l as BoxGeometry, m as CylinderGeometry, n as Grid, o as Canvas, p as ConeGeometry, r as CameraControls, s as useThree, t as ContactShadows, v as Plane, x as TubeGeometry, y as Shape } from "../_libs/@react-three/drei+[...].mjs";
import { C as EyeOff, E as Box, S as Eye, T as Camera, _ as LayoutGrid, a as Scan, b as FolderPlus, c as Redo2, d as MousePointer2, f as Maximize2, g as Library, h as LockOpen, i as SquareDashed, l as Plus, m as Lock, o as ScanEye, p as Magnet, r as Trash2, s as RotateCcw, t as Undo2, u as Move, v as Languages, w as Copy, x as FolderCog, y as Grid3x3 } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { t as mergeGeometries } from "../_libs/three.mjs";
import { t as Drawer } from "../_libs/vaul.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BbXpZJNS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PartGlyph({ kind, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 48 48",
		className,
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "48",
			height: "48",
			rx: "8",
			fill: "currentColor",
			opacity: "0.06"
		}), glyph(kind)]
	});
}
function glyph(kind) {
	const stroke = "currentColor";
	switch (kind) {
		case "hex-bolt": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			fill: "none",
			stroke,
			strokeWidth: "1.6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", { points: "24,8 32,12 32,20 24,24 16,20 16,12" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "21",
				y: "23",
				width: "6",
				height: "16",
				rx: "1"
			})]
		});
		case "hex-nut": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "24,10 34,16 34,28 24,34 14,28 14,16",
			fill: "none",
			stroke,
			strokeWidth: "1.6"
		});
		case "washer": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			fill: "none",
			stroke,
			strokeWidth: "1.6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "24",
				cy: "24",
				rx: "14",
				ry: "8"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "24",
				cy: "24",
				rx: "6",
				ry: "3.4"
			})]
		});
		case "standoff": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			fill: "none",
			stroke,
			strokeWidth: "1.6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "18",
				y: "14",
				width: "12",
				height: "20"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M24 8v6M24 34v6" })]
		});
		case "shaft": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
			fill: "none",
			stroke,
			strokeWidth: "1.6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "8",
				y: "20",
				width: "32",
				height: "8",
				rx: "4"
			})
		});
		case "block": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			fill: "none",
			stroke,
			strokeWidth: "1.6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M10 18 L24 12 L38 18 L38 32 L24 38 L10 32 Z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M24 12 V38" })]
		});
		case "plate": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			fill: "none",
			stroke,
			strokeWidth: "1.6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "8",
					y: "16",
					width: "32",
					height: "16",
					rx: "2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "14",
					cy: "24",
					r: "2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "34",
					cy: "24",
					r: "2"
				})
			]
		});
		case "pipe": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			fill: "none",
			stroke,
			strokeWidth: "1.6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "14",
					cy: "24",
					rx: "5",
					ry: "8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M14 16 H34 M14 32 H34" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "34",
					cy: "24",
					rx: "5",
					ry: "8"
				})
			]
		});
		case "hex-bar": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
			fill: "none",
			stroke,
			strokeWidth: "1.6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", { points: "16,18 24,14 32,18 32,30 24,34 16,30" })
		});
		case "angle-bar": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			fill: "none",
			stroke,
			strokeWidth: "1.6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M14 12 V36 H36" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M18 12 V32 H36" })]
		});
		case "l-bracket": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
			fill: "none",
			stroke,
			strokeWidth: "1.6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 14 H30 V20 H20 V36 H12 Z" })
		});
		case "flange": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			fill: "none",
			stroke,
			strokeWidth: "1.6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "24",
					cy: "24",
					r: "13"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "24",
					cy: "24",
					r: "5"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "24",
					cy: "12.5",
					r: "1.4",
					fill: stroke
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "24",
					cy: "35.5",
					r: "1.4",
					fill: stroke
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "12.5",
					cy: "24",
					r: "1.4",
					fill: stroke
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "35.5",
					cy: "24",
					r: "1.4",
					fill: stroke
				})
			]
		});
		case "spur-gear": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			fill: "none",
			stroke,
			strokeWidth: "1.6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "24",
				cy: "24",
				r: "7"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M24 10 v4 M24 34 v4 M10 24 h4 M34 24 h4 M13.5 13.5 l3 3 M31.5 31.5 l3 3 M13.5 34.5 l3-3 M31.5 16.5 l3-3" })]
		});
		case "bearing": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			fill: "none",
			stroke,
			strokeWidth: "1.6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "24",
					cy: "24",
					r: "12"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "24",
					cy: "24",
					r: "5"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "24",
					cy: "15",
					r: "2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "32",
					cy: "24",
					r: "2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "24",
					cy: "33",
					r: "2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "16",
					cy: "24",
					r: "2"
				})
			]
		});
		case "pulley": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			fill: "none",
			stroke,
			strokeWidth: "1.6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "24",
					cy: "18",
					rx: "12",
					ry: "6"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 18 V30" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M36 18 V30" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "24",
					cy: "30",
					rx: "12",
					ry: "6"
				})
			]
		});
		case "coupling": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			fill: "none",
			stroke,
			strokeWidth: "1.6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "10",
					y: "18",
					width: "12",
					height: "12",
					rx: "2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "26",
					y: "18",
					width: "12",
					height: "12",
					rx: "2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M22 24 H26" })
			]
		});
		case "spring": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
			fill: "none",
			stroke,
			strokeWidth: "1.6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16 12 c8 0 8 6 0 6 s-8 6 0 6 8 6 0 6 8 6 0 6" })
		});
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "14",
			y: "14",
			width: "20",
			height: "20",
			fill: "none",
			stroke,
			strokeWidth: "1.6"
		});
	}
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("flex h-11 w-full rounded-md border border-border bg-surface px-3 text-sm text-fg tabular-nums", "placeholder:text-faint focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50", "disabled:opacity-40", className),
		...props
	});
}
var CATALOG = {
	"hex-bolt": {
		kind: "hex-bolt",
		category: "fastener",
		labelFa: "پیچ شش‌گوش",
		labelEn: "Hex bolt",
		blurbFa: "پیچ متریک با سر شش‌گوش و رزوه",
		blurbEn: "Metric hex-head bolt with thread",
		params: [
			p("d", 8, 3, 30, .5, "mm", "قطر", "Diameter"),
			p("L", 32, 8, 120, 1, "mm", "طول", "Length"),
			p("af", 13, 5, 46, .5, "mm", "آچارخور", "Across flats"),
			p("headH", 5.3, 2, 20, .1, "mm", "ارتفاع سر", "Head height"),
			p("thread", 22, 4, 110, 1, "mm", "طول رزوه", "Thread length")
		]
	},
	"hex-nut": {
		kind: "hex-nut",
		category: "fastener",
		labelFa: "مهره شش‌گوش",
		labelEn: "Hex nut",
		blurbFa: "مهره متریک با سوراخ رزوه",
		blurbEn: "Metric hex nut",
		params: [
			p("d", 8, 3, 30, .5, "mm", "قطر سوراخ", "Hole"),
			p("af", 13, 5, 46, .5, "mm", "آچارخور", "Across flats"),
			p("t", 6.5, 2, 24, .1, "mm", "ضخامت", "Thickness")
		]
	},
	washer: {
		kind: "washer",
		category: "fastener",
		labelFa: "واشر",
		labelEn: "Washer",
		blurbFa: "واشر تخت فولادی",
		blurbEn: "Flat washer",
		params: [
			p("d", 8.4, 3, 36, .1, "mm", "قطر داخلی", "Inner dia"),
			p("od", 16, 6, 60, .5, "mm", "قطر خارجی", "Outer dia"),
			p("t", 1.6, .4, 8, .1, "mm", "ضخامت", "Thickness")
		]
	},
	standoff: {
		kind: "standoff",
		category: "fastener",
		labelFa: "اسپیسر",
		labelEn: "Standoff",
		blurbFa: "فاصله‌گذار شش‌گوش با پین",
		blurbEn: "Hex standoff with pins",
		params: [
			p("d", 6, 3, 16, .5, "mm", "قطر پین", "Pin dia"),
			p("af", 10, 5, 24, .5, "mm", "آچارخور", "Across flats"),
			p("L", 20, 6, 80, 1, "mm", "طول بدنه", "Body")
		]
	},
	shaft: {
		kind: "shaft",
		category: "stock",
		labelFa: "شفت",
		labelEn: "Shaft",
		blurbFa: "میل‌گرد با پخ انتهایی",
		blurbEn: "Round shaft with chamfer",
		params: [p("d", 16, 4, 60, .5, "mm", "قطر", "Diameter"), p("L", 90, 16, 260, 1, "mm", "طول", "Length")]
	},
	block: {
		kind: "block",
		category: "stock",
		labelFa: "بلوک",
		labelEn: "Block",
		blurbFa: "مکعب مستطیل ماشین‌کاری",
		blurbEn: "Rectangular stock block",
		params: [
			p("w", 40, 8, 180, 1, "mm", "طول", "Width"),
			p("h", 24, 6, 120, 1, "mm", "ارتفاع", "Height"),
			p("d", 30, 6, 160, 1, "mm", "عمق", "Depth")
		]
	},
	plate: {
		kind: "plate",
		category: "stock",
		labelFa: "ورق",
		labelEn: "Plate",
		blurbFa: "ورق با چهار سوراخ گوشه",
		blurbEn: "Plate with corner holes",
		params: [
			p("w", 120, 20, 280, 1, "mm", "طول", "Width"),
			p("d", 80, 16, 220, 1, "mm", "عرض", "Depth"),
			p("t", 8, 2, 30, .5, "mm", "ضخامت", "Thickness"),
			p("hole", 6.6, 0, 20, .1, "mm", "قطر سوراخ", "Hole"),
			p("margin", 12, 6, 40, 1, "mm", "حاشیه سوراخ", "Margin")
		]
	},
	pipe: {
		kind: "pipe",
		category: "stock",
		labelFa: "لوله",
		labelEn: "Tube",
		blurbFa: "لوله جدارنازک",
		blurbEn: "Hollow tube",
		params: [
			p("od", 32, 8, 90, .5, "mm", "قطر خارجی", "Outer dia"),
			p("id", 26, 4, 84, .5, "mm", "قطر داخلی", "Inner dia"),
			p("L", 70, 12, 240, 1, "mm", "طول", "Length")
		]
	},
	"hex-bar": {
		kind: "hex-bar",
		category: "stock",
		labelFa: "میل شش‌گوش",
		labelEn: "Hex bar",
		blurbFa: "پروفیل شش‌ضلعی",
		blurbEn: "Hexagonal bar stock",
		params: [p("af", 14, 6, 40, .5, "mm", "آچارخور", "Across flats"), p("L", 60, 12, 220, 1, "mm", "طول", "Length")]
	},
	"angle-bar": {
		kind: "angle-bar",
		category: "frame",
		labelFa: "نبشی",
		labelEn: "Angle bar",
		blurbFa: "پروفیل نبشی L",
		blurbEn: "L-profile angle",
		params: [
			p("a", 30, 10, 80, 1, "mm", "بال الف", "Leg A"),
			p("b", 30, 10, 80, 1, "mm", "بال ب", "Leg B"),
			p("t", 3, 1.5, 12, .5, "mm", "ضخامت", "Thickness"),
			p("L", 90, 20, 260, 1, "mm", "طول", "Length")
		]
	},
	"l-bracket": {
		kind: "l-bracket",
		category: "frame",
		labelFa: "گونیا",
		labelEn: "L-bracket",
		blurbFa: "براکت ۹۰ درجه سوراخ‌دار",
		blurbEn: "Right-angle bracket",
		params: [
			p("a", 48, 16, 100, 1, "mm", "بال الف", "Leg A"),
			p("b", 40, 16, 100, 1, "mm", "بال ب", "Leg B"),
			p("w", 28, 12, 80, 1, "mm", "عرض", "Width"),
			p("t", 4, 2, 12, .5, "mm", "ضخامت", "Thickness"),
			p("hole", 5, 0, 12, .5, "mm", "سوراخ", "Hole")
		]
	},
	flange: {
		kind: "flange",
		category: "frame",
		labelFa: "فلنج",
		labelEn: "Flange",
		blurbFa: "فلنج دایره‌ای با دایره پیچ",
		blurbEn: "Circular flange with bolt circle",
		params: [
			p("od", 76, 28, 160, 1, "mm", "قطر خارجی", "Outer dia"),
			p("id", 18, 4, 80, .5, "mm", "قطر داخلی", "Bore"),
			p("t", 10, 4, 28, .5, "mm", "ضخامت", "Thickness"),
			p("bolts", 4, 3, 12, 1, "count", "تعداد پیچ", "Bolts"),
			p("hole", 7, 3, 16, .5, "mm", "قطر سوراخ", "Hole"),
			p("pcd", 52, 18, 130, 1, "mm", "دایره پیچ", "PCD")
		]
	},
	"spur-gear": {
		kind: "spur-gear",
		category: "drive",
		labelFa: "چرخ‌دنده",
		labelEn: "Spur gear",
		blurbFa: "چرخ‌دنده ساده پارامتری",
		blurbEn: "Parametric spur gear",
		params: [
			p("teeth", 18, 8, 48, 1, "count", "تعداد دندانه", "Teeth"),
			p("module", 2.5, 1, 6, .1, "mm", "مدول", "Module"),
			p("thickness", 10, 3, 28, .5, "mm", "ضخامت", "Thickness"),
			p("bore", 12, 4, 40, .5, "mm", "قطر سوراخ", "Bore")
		]
	},
	bearing: {
		kind: "bearing",
		category: "drive",
		labelFa: "بلبرینگ",
		labelEn: "Bearing",
		blurbFa: "بلبرینگ شیار عمیق",
		blurbEn: "Deep-groove ball bearing",
		params: [
			p("od", 35, 16, 80, 1, "mm", "قطر خارجی", "Outer dia"),
			p("id", 15, 6, 50, .5, "mm", "قطر داخلی", "Inner dia"),
			p("w", 11, 5, 24, .5, "mm", "عرض", "Width")
		]
	},
	pulley: {
		kind: "pulley",
		category: "drive",
		labelFa: "پولی",
		labelEn: "Pulley",
		blurbFa: "پولی تسمه‌ای شیاردار",
		blurbEn: "V-groove pulley",
		params: [
			p("od", 44, 16, 100, 1, "mm", "قطر", "Diameter"),
			p("w", 14, 6, 36, .5, "mm", "عرض", "Width"),
			p("groove", 5, 2, 12, .5, "mm", "شیار", "Groove"),
			p("bore", 10, 4, 30, .5, "mm", "سوراخ", "Bore")
		]
	},
	coupling: {
		kind: "coupling",
		category: "drive",
		labelFa: "کوپلینگ",
		labelEn: "Coupling",
		blurbFa: "کوپلینگ صلب شفت",
		blurbEn: "Rigid shaft coupling",
		params: [
			p("od", 28, 14, 70, 1, "mm", "قطر", "Diameter"),
			p("L", 32, 16, 80, 1, "mm", "طول", "Length"),
			p("bore", 10, 4, 36, .5, "mm", "سوراخ", "Bore")
		]
	},
	spring: {
		kind: "spring",
		category: "drive",
		labelFa: "فنر",
		labelEn: "Spring",
		blurbFa: "فنر فشاری مارپیچ",
		blurbEn: "Compression coil spring",
		params: [
			p("d", 16, 6, 40, .5, "mm", "قطر", "Diameter"),
			p("wire", 2, .8, 5, .1, "mm", "سیم", "Wire"),
			p("L", 36, 10, 100, 1, "mm", "طول", "Length"),
			p("coils", 8, 4, 18, 1, "count", "حلقه", "Coils")
		]
	}
};
var CATEGORIES = [
	{
		id: "fastener",
		fa: "اتصالات",
		en: "Fasteners"
	},
	{
		id: "stock",
		fa: "مقاطع",
		en: "Stock"
	},
	{
		id: "frame",
		fa: "سازه‌ای",
		en: "Frame"
	},
	{
		id: "drive",
		fa: "انتقال قدرت",
		en: "Drive"
	}
];
var BOLT_PRESETS = [
	{
		id: "M4",
		d: 4,
		af: 7,
		headH: 2.8,
		t: 3.2
	},
	{
		id: "M5",
		d: 5,
		af: 8,
		headH: 3.5,
		t: 4
	},
	{
		id: "M6",
		d: 6,
		af: 10,
		headH: 4,
		t: 5
	},
	{
		id: "M8",
		d: 8,
		af: 13,
		headH: 5.3,
		t: 6.5
	},
	{
		id: "M10",
		d: 10,
		af: 16,
		headH: 6.4,
		t: 8
	},
	{
		id: "M12",
		d: 12,
		af: 18,
		headH: 7.5,
		t: 10
	}
];
function defaultParams(kind) {
	const out = {};
	for (const param of CATALOG[kind].params) out[param.key] = param.value;
	return out;
}
function paramLabel(def, lang) {
	return lang === "fa" ? def.labelFa : def.labelEn;
}
function partLabel(kind, lang) {
	return lang === "fa" ? CATALOG[kind].labelFa : CATALOG[kind].labelEn;
}
function partSizeHint(kind, params) {
	return CATALOG[kind].params.slice(0, 3).map((param) => {
		const v = params[param.key] ?? param.value;
		if (param.unit === "count") return `${Math.round(v)}`;
		return `${trimNum(v)}`;
	}).join(" × ");
}
function trimNum(n) {
	const r = Math.round(n * 10) / 10;
	return Number.isInteger(r) ? String(r) : r.toFixed(1);
}
function p(key, value, min, max, step, unit, labelFa, labelEn) {
	return {
		key,
		value,
		min,
		max,
		step,
		unit,
		labelFa,
		labelEn
	};
}
var dict = {
	fa: {
		app: "آلیاژ",
		tagline: "طراحی قطعات مکانیکی سه‌بعدی",
		add: "افزودن قطعه",
		library: "کتابخانه",
		parts: "قطعات",
		view: "نما",
		project: "پروژه",
		properties: "ویژگی‌ها",
		scene: "صحنه",
		select: "انتخاب",
		move: "جابه‌جایی",
		rotate: "چرخش",
		duplicate: "تکثیر",
		delete: "حذف",
		hide: "پنهان",
		show: "نمایش",
		lock: "قفل",
		unlock: "باز",
		undo: "بازگشت",
		redo: "پیشرفت",
		grid: "شبکه",
		snap: "چسبندگی",
		section: "برش",
		explode: "انفجار مونتاژ",
		fit: "جا شدن",
		iso: "ایزو",
		front: "جلو",
		top: "بالا",
		right: "راست",
		left: "چپ",
		newProject: "پروژه تازه",
		loadSample: "نمونه مونتاژ",
		exportPng: "خروجی تصویر",
		rename: "نام پروژه",
		units: "میلی‌متر",
		material: "جنس",
		transform: "موقعیت",
		rot: "دوران",
		emptyTitle: "صحنه خالی است",
		emptyBody: "از کتابخانه یک قطعه پارامتری اضافه کنید یا نمونه مونتاژ را باز کنید.",
		noSelection: "قطعه‌ای انتخاب نشده",
		noSelectionHint: "روی یک قطعه در صحنه بزنید یا از فهرست انتخاب کنید.",
		sampleName: "گیربکس رومیزی",
		untitled: "بدون‌نام",
		partsCount: "قطعه",
		metric: "سایز متریک",
		search: "جستجوی قطعه",
		about: "استودیوی طراحی قطعات مکانیکی برای موبایل و دسکتاپ. پارامترها را عوض کنید، مونتاژ بسازید و ذخیره می‌شود روی همین دستگاه.",
		close: "بستن",
		posX: "X",
		posY: "Y",
		posZ: "Z",
		language: "زبان",
		selected: "انتخاب‌شده",
		visible: "قابل‌مشاهده"
	},
	en: {
		app: "Alyazh",
		tagline: "3D mechanical part design",
		add: "Add part",
		library: "Library",
		parts: "Parts",
		view: "View",
		project: "Project",
		properties: "Properties",
		scene: "Scene",
		select: "Select",
		move: "Move",
		rotate: "Rotate",
		duplicate: "Duplicate",
		delete: "Delete",
		hide: "Hide",
		show: "Show",
		lock: "Lock",
		unlock: "Unlock",
		undo: "Undo",
		redo: "Redo",
		grid: "Grid",
		snap: "Snap",
		section: "Section",
		explode: "Explode",
		fit: "Fit",
		iso: "Iso",
		front: "Front",
		top: "Top",
		right: "Right",
		left: "Left",
		newProject: "New project",
		loadSample: "Load sample",
		exportPng: "Export image",
		rename: "Project name",
		units: "millimeters",
		material: "Material",
		transform: "Position",
		rot: "Rotation",
		emptyTitle: "Empty scene",
		emptyBody: "Add a parametric part from the library, or open the sample assembly.",
		noSelection: "Nothing selected",
		noSelectionHint: "Tap a part in the viewport or pick one from the list.",
		sampleName: "Desktop gearbox",
		untitled: "Untitled",
		partsCount: "parts",
		metric: "Metric size",
		search: "Search parts",
		about: "A mechanical parts studio for phone and desktop. Tweak parameters, build an assembly, and it stays on this device.",
		close: "Close",
		posX: "X",
		posY: "Y",
		posZ: "Z",
		language: "Language",
		selected: "Selected",
		visible: "visible"
	}
};
function t(lang, key) {
	return dict[lang][key];
}
var seq = 0;
function uid() {
	seq += 1;
	return `p${Date.now().toString(36)}${seq.toString(36)}`;
}
function makePart(kind, patch = {}) {
	const params = {
		...defaultParams(kind),
		...patch.params
	};
	return {
		id: patch.id ?? uid(),
		kind,
		name: patch.name ?? CATALOG[kind].labelFa,
		params,
		position: patch.position ?? [
			0,
			0,
			0
		],
		rotation: patch.rotation ?? [
			0,
			0,
			0
		],
		material: patch.material ?? defaultMaterial(kind),
		visible: patch.visible ?? true,
		locked: patch.locked ?? false
	};
}
function defaultMaterial(kind) {
	if (kind === "spur-gear" || kind === "pulley") return "steel";
	if (kind === "bearing") return "stainless";
	if (kind === "plate" || kind === "l-bracket" || kind === "block") return "aluminum";
	if (kind === "spring") return "steel";
	if (kind === "washer") return "stainless";
	return "steel";
}
function sampleAssembly() {
	const plateT = 10;
	const plateW = 170;
	const plateD = 100;
	const flangeOd = 72;
	const flangeT = 10;
	const shaftD = 16;
	const yPlate = plateT / 2;
	const yAxis = 46;
	const parts = [
		makePart("plate", {
			name: "صفحه پایه",
			material: "aluminum",
			params: {
				w: plateW,
				d: plateD,
				t: plateT,
				hole: 7,
				margin: 14
			},
			position: [
				0,
				yPlate,
				0
			]
		}),
		makePart("flange", {
			name: "فلنج راست",
			material: "steel",
			params: {
				od: flangeOd,
				id: 16.4,
				t: flangeT,
				bolts: 4,
				hole: 7,
				pcd: 50
			},
			position: [
				10,
				yAxis,
				0
			],
			rotation: [
				0,
				0,
				90
			]
		}),
		makePart("flange", {
			name: "فلنج چپ",
			material: "steel",
			params: {
				od: flangeOd,
				id: 16.4,
				t: flangeT,
				bolts: 4,
				hole: 7,
				pcd: 50
			},
			position: [
				-10,
				yAxis,
				0
			],
			rotation: [
				0,
				0,
				90
			]
		}),
		makePart("shaft", {
			name: "شفت اصلی",
			material: "stainless",
			params: {
				d: shaftD,
				L: 128
			},
			position: [
				18,
				yAxis,
				0
			],
			rotation: [
				0,
				0,
				90
			]
		}),
		makePart("spur-gear", {
			name: "چرخ‌دنده",
			material: "steel",
			params: {
				teeth: 18,
				module: 2.4,
				thickness: 12,
				bore: shaftD
			},
			position: [
				52,
				yAxis,
				0
			],
			rotation: [
				0,
				0,
				90
			]
		}),
		makePart("bearing", {
			name: "بلبرینگ",
			material: "stainless",
			params: {
				od: 35,
				id: 15,
				w: 11
			},
			position: [
				-48,
				yAxis,
				0
			],
			rotation: [
				0,
				0,
				90
			]
		}),
		makePart("pulley", {
			name: "پولی",
			material: "aluminum",
			params: {
				od: 40,
				w: 14,
				groove: 5,
				bore: 14
			},
			position: [
				-70,
				yAxis,
				0
			],
			rotation: [
				0,
				0,
				90
			]
		})
	];
	const pcd = 50;
	for (let i = 0; i < 4; i++) {
		const a = i / 4 * Math.PI * 2 + Math.PI / 4;
		const y = yAxis + Math.sin(a) * (pcd / 2);
		const z = Math.cos(a) * (pcd / 2);
		parts.push(makePart("hex-bolt", {
			name: `پیچ فلنج ${i + 1}`,
			material: "steel",
			params: {
				d: 6,
				L: 28,
				af: 10,
				headH: 4,
				thread: 18
			},
			position: [
				16,
				y,
				z
			],
			rotation: [
				0,
				0,
				90
			]
		}));
		parts.push(makePart("hex-nut", {
			name: `مهره فلنج ${i + 1}`,
			material: "steel",
			params: {
				d: 6,
				af: 10,
				t: 5
			},
			position: [
				-16,
				y,
				z
			],
			rotation: [
				0,
				0,
				90
			]
		}));
	}
	[
		[
			71,
			0,
			36
		],
		[
			-71,
			0,
			36
		],
		[
			71,
			0,
			-36
		],
		[
			-71,
			0,
			-36
		]
	].forEach((c, i) => {
		const headH = 5.3;
		const L = 22;
		parts.push(makePart("washer", {
			name: `واشر ${i + 1}`,
			material: "stainless",
			params: {
				d: 8.4,
				od: 16,
				t: 1.6
			},
			position: [
				c[0],
				10.9,
				c[2]
			]
		}));
		parts.push(makePart("hex-bolt", {
			name: `پیچ پایه ${i + 1}`,
			material: "steel",
			params: {
				d: 8,
				L,
				af: 13,
				headH,
				thread: 16
			},
			position: [
				c[0],
				3.2500000000000004,
				c[2]
			]
		}));
	});
	return {
		name: "گیربکس رومیزی",
		parts
	};
}
function emptyProject() {
	return {
		name: "بدون‌نام",
		parts: []
	};
}
function nextPlacement(existing, kind) {
	const nParts = existing.length;
	const col = nParts % 5;
	const row = Math.floor(nParts / 5);
	const lift = liftFor(kind, defaultParams(kind));
	return [
		col * 48 - 96,
		lift,
		row * 48 - 48
	];
}
function liftFor(kind, params) {
	switch (kind) {
		case "hex-bolt": return (params.headH + params.L) / 2;
		case "hex-nut": return params.t / 2;
		case "washer": return params.t / 2;
		case "shaft":
		case "hex-bar":
		case "pipe":
		case "spring":
		case "standoff":
		case "coupling": return params.L / 2;
		case "block": return params.h / 2;
		case "plate": return params.t / 2;
		case "angle-bar": return Math.max(params.a, params.b) / 2;
		case "l-bracket": return Math.max(params.a, params.b) / 2;
		case "flange": return params.t / 2;
		case "spur-gear": return params.thickness / 2;
		case "bearing": return params.w / 2;
		case "pulley": return params.w / 2;
		default: return 10;
	}
}
var sample = sampleAssembly();
function cloneParts(parts) {
	return structuredClone(parts);
}
function withHistory(set, get, mutate) {
	const { parts, past } = get();
	set({
		parts: mutate(cloneParts(parts)),
		past: [...past.slice(-48), cloneParts(parts)],
		future: []
	});
}
var useCadStore = create()(persist((set, get) => ({
	name: sample.name,
	parts: sample.parts,
	selectedId: sample.parts[4]?.id ?? null,
	lang: "fa",
	tool: "select",
	panel: "none",
	grid: true,
	snap: true,
	snapStep: 1,
	section: false,
	explode: 0,
	viewTick: null,
	captureTick: 0,
	past: [],
	future: [],
	hydrated: false,
	setHydrated: (v) => set({ hydrated: v }),
	setLang: (lang) => set({ lang }),
	setTool: (tool) => set({ tool }),
	setPanel: (panel) => set({ panel }),
	select: (id) => set({ selectedId: id }),
	addPart: (kind) => {
		withHistory(set, get, (parts) => {
			const part = makePart(kind, {
				name: get().lang === "fa" ? CATALOG[kind].labelFa : CATALOG[kind].labelEn,
				position: nextPlacement(parts, kind),
				params: defaultParams(kind)
			});
			set({
				selectedId: part.id,
				panel: get().panel === "library" ? "props" : get().panel
			});
			return [...parts, part];
		});
	},
	updateParams: (id, params) => {
		withHistory(set, get, (parts) => parts.map((p) => p.id === id ? {
			...p,
			params: {
				...p.params,
				...params
			}
		} : p));
	},
	applyBoltPreset: (id, presetId) => {
		const preset = BOLT_PRESETS.find((b) => b.id === presetId);
		if (!preset) return;
		withHistory(set, get, (parts) => parts.map((p) => {
			if (p.id !== id) return p;
			if (p.kind === "hex-bolt") return {
				...p,
				params: {
					...p.params,
					d: preset.d,
					af: preset.af,
					headH: preset.headH,
					thread: Math.min(p.params.thread ?? 22, p.params.L ?? 32)
				}
			};
			if (p.kind === "hex-nut") return {
				...p,
				params: {
					...p.params,
					d: preset.d,
					af: preset.af,
					t: preset.t
				}
			};
			return p;
		}));
	},
	setMaterial: (id, material) => {
		withHistory(set, get, (parts) => parts.map((p) => p.id === id ? {
			...p,
			material
		} : p));
	},
	setTransform: (id, position, rotation) => {
		set({ parts: get().parts.map((p) => p.id === id ? {
			...p,
			position,
			rotation
		} : p) });
	},
	commitTransform: () => {
		const { parts, past } = get();
		const last = past[past.length - 1];
		if (last && JSON.stringify(last) === JSON.stringify(parts)) return;
		set({
			past: [...past.slice(-48), last ? last : cloneParts(parts)],
			future: []
		});
	},
	renamePart: (id, name) => {
		set({ parts: get().parts.map((p) => p.id === id ? {
			...p,
			name
		} : p) });
	},
	duplicateSelected: () => {
		const { selectedId } = get();
		if (!selectedId) return;
		withHistory(set, get, (parts) => {
			const src = parts.find((p) => p.id === selectedId);
			if (!src) return parts;
			const copy = {
				...structuredClone(src),
				id: uid(),
				name: `${src.name} ·۲`,
				position: [
					src.position[0] + 16,
					src.position[1],
					src.position[2] + 16
				]
			};
			set({ selectedId: copy.id });
			return [...parts, copy];
		});
	},
	deleteSelected: () => {
		const { selectedId } = get();
		if (!selectedId) return;
		withHistory(set, get, (parts) => {
			const next = parts.filter((p) => p.id !== selectedId);
			set({ selectedId: next.at(-1)?.id ?? null });
			return next;
		});
	},
	toggleVisible: (id) => {
		set({ parts: get().parts.map((p) => p.id === id ? {
			...p,
			visible: !p.visible
		} : p) });
	},
	toggleLocked: (id) => {
		set({ parts: get().parts.map((p) => p.id === id ? {
			...p,
			locked: !p.locked
		} : p) });
	},
	toggleGrid: () => set({ grid: !get().grid }),
	toggleSnap: () => set({ snap: !get().snap }),
	toggleSection: () => set({ section: !get().section }),
	setExplode: (v) => set({ explode: v }),
	requestView: (preset) => set({ viewTick: preset }),
	clearView: () => set({ viewTick: null }),
	requestCapture: () => set({ captureTick: get().captureTick + 1 }),
	undo: () => {
		const { past, parts, future } = get();
		const prev = past.at(-1);
		if (!prev) return;
		set({
			parts: prev,
			past: past.slice(0, -1),
			future: [cloneParts(parts), ...future].slice(0, 48),
			selectedId: prev.find((p) => p.id === get().selectedId)?.id ?? prev.at(-1)?.id ?? null
		});
	},
	redo: () => {
		const { future, parts, past } = get();
		const next = future[0];
		if (!next) return;
		set({
			parts: next,
			future: future.slice(1),
			past: [...past, cloneParts(parts)]
		});
	},
	newProject: () => {
		const empty = emptyProject();
		withHistory(set, get, () => empty.parts);
		set({
			name: empty.name,
			selectedId: null,
			panel: "library",
			explode: 0
		});
	},
	loadSample: () => {
		const demo = sampleAssembly();
		withHistory(set, get, () => demo.parts);
		set({
			name: demo.name,
			selectedId: demo.parts[4]?.id ?? null,
			panel: "none",
			explode: 0
		});
	},
	setName: (name) => set({ name })
}), {
	name: "alyazh-cad-v1",
	partialize: (s) => ({
		name: s.name,
		parts: s.parts,
		selectedId: s.selectedId,
		lang: s.lang,
		tool: s.tool,
		grid: s.grid,
		snap: s.snap,
		section: s.section,
		explode: s.explode
	}),
	onRehydrateStorage: () => (state) => {
		state?.setHydrated(true);
	}
}));
function LibraryPanel() {
	const lang = useCadStore((s) => s.lang);
	const addPart = useCadStore((s) => s.addPart);
	const setPanel = useCadStore((s) => s.setPanel);
	const [q, setQ] = (0, import_react.useState)("");
	const query = q.trim().toLowerCase();
	const groups = (0, import_react.useMemo)(() => {
		return CATEGORIES.map((cat) => {
			return {
				cat,
				items: Object.keys(CATALOG).filter((kind) => {
					const def = CATALOG[kind];
					if (def.category !== cat.id) return false;
					if (!query) return true;
					return def.labelFa.includes(q.trim()) || def.labelEn.toLowerCase().includes(query) || def.blurbFa.includes(q.trim()) || def.blurbEn.toLowerCase().includes(query);
				})
			};
		}).filter((g) => g.items.length > 0);
	}, [query, q]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			value: q,
			onChange: (e) => setQ(e.target.value),
			placeholder: t(lang, "search"),
			"aria-label": t(lang, "search")
		}), groups.map(({ cat, items }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex flex-col gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-xs font-medium uppercase tracking-wide text-muted",
				children: lang === "fa" ? cat.fa : cat.en
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2",
				children: items.map((kind) => {
					const def = CATALOG[kind];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							addPart(kind);
							setPanel("none");
						},
						className: cn("flex flex-col items-start gap-2 rounded-lg bg-surface-2 p-3 text-start", "shadow-[0_0_0_1px_rgba(255,255,255,0.06)] transition-colors duration-150", "hover:bg-surface-2/80 min-h-11"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartGlyph, {
								kind,
								className: "size-10 text-accent"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium text-fg",
								children: partLabel(kind, lang)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs leading-snug text-muted",
								children: lang === "fa" ? def.blurbFa : def.blurbEn
							})
						]
					}, kind);
				})
			})]
		}, cat.id))]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[transform,background-color,color,box-shadow,opacity] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60 disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg shadow-sm hover:bg-accent/90",
			secondary: "bg-surface-2 text-fg hover:bg-surface-2/80",
			ghost: "text-fg hover:bg-surface-2",
			outline: "border border-border bg-transparent text-fg hover:bg-surface-2",
			danger: "bg-danger text-fg hover:bg-danger/90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 rounded-sm px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11",
			"icon-sm": "size-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function PartsPanel() {
	const lang = useCadStore((s) => s.lang);
	const parts = useCadStore((s) => s.parts);
	const selectedId = useCadStore((s) => s.selectedId);
	const select = useCadStore((s) => s.select);
	const toggleVisible = useCadStore((s) => s.toggleVisible);
	const toggleLocked = useCadStore((s) => s.toggleLocked);
	const duplicateSelected = useCadStore((s) => s.duplicateSelected);
	const deleteSelected = useCadStore((s) => s.deleteSelected);
	const setPanel = useCadStore((s) => s.setPanel);
	if (parts.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2 py-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-medium text-fg",
			children: t(lang, "emptyTitle")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm leading-normal text-muted",
			children: t(lang, "emptyBody")
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-1",
		children: [parts.map((part) => {
			const active = part.id === selectedId;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("flex items-center gap-2 rounded-md px-2 py-1.5", active ? "bg-surface-2" : "hover:bg-surface-2/60"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							select(part.id);
							setPanel("props");
						},
						className: "flex min-h-11 min-w-0 flex-1 items-center gap-2 text-start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartGlyph, {
							kind: part.kind,
							className: "size-8 shrink-0 text-accent"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-sm text-fg",
								children: part.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block truncate text-xs tabular-nums text-muted",
								children: [
									partLabel(part.kind, lang),
									" · ",
									partSizeHint(part.kind, part.params)
								]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						"aria-label": part.visible ? t(lang, "hide") : t(lang, "show"),
						onClick: () => toggleVisible(part.id),
						children: part.visible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						"aria-label": part.locked ? t(lang, "unlock") : t(lang, "lock"),
						onClick: () => toggleLocked(part.id),
						children: part.locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockOpen, {})
					})
				]
			}, part.id);
		}), selectedId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "secondary",
				className: "flex-1",
				onClick: duplicateSelected,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), t(lang, "duplicate")]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				className: "flex-1",
				onClick: deleteSelected,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), t(lang, "delete")]
			})]
		}) : null]
	});
}
function Separator({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("h-px w-full bg-border", className) });
}
function ProjectPanel() {
	const lang = useCadStore((s) => s.lang);
	const name = useCadStore((s) => s.name);
	const parts = useCadStore((s) => s.parts);
	const setName = useCadStore((s) => s.setName);
	const newProject = useCadStore((s) => s.newProject);
	const loadSample = useCadStore((s) => s.loadSample);
	const requestCapture = useCadStore((s) => s.requestCapture);
	const setLang = useCadStore((s) => s.setLang);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex flex-col gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium text-muted",
					children: t(lang, "rename")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: name,
					onChange: (e) => setName(e.target.value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm tabular-nums text-muted",
				children: [
					parts.length,
					" ",
					t(lang, "partsCount"),
					" · ",
					t(lang, "units")
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						onClick: newProject,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderPlus, {}), t(lang, "newProject")]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						onClick: loadSample,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, {}), t(lang, "loadSample")]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: requestCapture,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {}), t(lang, "exportPng")]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium text-muted",
					children: t(lang, "language")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => setLang(lang === "fa" ? "en" : "fa"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Languages, {}), lang === "fa" ? "English" : "فارسی"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-normal text-muted",
				children: t(lang, "about")
			})
		]
	});
}
function Slider({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
		className: cn("relative flex w-full touch-none items-center select-none", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
			className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-surface-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-accent" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full bg-fg shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60" })]
	});
}
var MATERIALS = {
	steel: {
		color: "#8d939c",
		metalness: .82,
		roughness: .34,
		labelFa: "فولاد",
		labelEn: "Steel"
	},
	stainless: {
		color: "#c5ccd3",
		metalness: .92,
		roughness: .18,
		labelFa: "استیل",
		labelEn: "Stainless"
	},
	aluminum: {
		color: "#b7bec6",
		metalness: .62,
		roughness: .42,
		labelFa: "آلومینیوم",
		labelEn: "Aluminum"
	},
	brass: {
		color: "#c4a15c",
		metalness: .78,
		roughness: .28,
		labelFa: "برنج",
		labelEn: "Brass"
	},
	copper: {
		color: "#b56a3e",
		metalness: .8,
		roughness: .3,
		labelFa: "مس",
		labelEn: "Copper"
	},
	titanium: {
		color: "#9aa0ab",
		metalness: .7,
		roughness: .38,
		labelFa: "تیتانیوم",
		labelEn: "Titanium"
	},
	nylon: {
		color: "#d9d4c8",
		metalness: .04,
		roughness: .72,
		labelFa: "نایلون",
		labelEn: "Nylon"
	},
	rubber: {
		color: "#2c2c30",
		metalness: .02,
		roughness: .92,
		labelFa: "لاستیک",
		labelEn: "Rubber"
	}
};
var SCENE = {
	clear: "#0c0e11",
	hemiSky: "#d7dde4",
	hemiGround: "#1b1814",
	key: "#f2f0ea",
	fill: "#8ea0b4",
	rim: "#c3b7a4",
	gridCell: "#2e343e",
	gridSection: "#4d5866",
	edge: "#16181d",
	edgeSelected: "#c9d4e0",
	gizmo: "#9aadc0"
};
var MATERIAL_IDS = [
	"steel",
	"stainless",
	"aluminum",
	"brass",
	"copper",
	"titanium",
	"nylon",
	"rubber"
];
function PropertiesPanel() {
	const lang = useCadStore((s) => s.lang);
	const parts = useCadStore((s) => s.parts);
	const selectedId = useCadStore((s) => s.selectedId);
	const part = parts.find((p) => p.id === selectedId);
	if (!part) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2 py-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-medium text-fg",
			children: t(lang, "noSelection")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm leading-normal text-muted",
			children: t(lang, "noSelectionHint")
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartEditor, { part });
}
function PartEditor({ part }) {
	const lang = useCadStore((s) => s.lang);
	const updateParams = useCadStore((s) => s.updateParams);
	const applyBoltPreset = useCadStore((s) => s.applyBoltPreset);
	const setMaterial = useCadStore((s) => s.setMaterial);
	const setTransform = useCadStore((s) => s.setTransform);
	const renamePart = useCadStore((s) => s.renamePart);
	const def = CATALOG[part.kind];
	const showMetric = part.kind === "hex-bolt" || part.kind === "hex-nut";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex flex-col gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium text-muted",
					children: lang === "fa" ? def.labelFa : def.labelEn
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: part.name,
					onChange: (e) => renamePart(part.id, e.target.value)
				})]
			}),
			showMetric ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium text-muted",
					children: t(lang, "metric")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: BOLT_PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => applyBoltPreset(part.id, preset.id),
						className: cn("h-9 rounded-sm px-3 text-xs font-medium tabular-nums", part.params.d === preset.d ? "bg-accent text-accent-fg" : "bg-surface-2 text-fg hover:bg-surface-2/80"),
						children: preset.id
					}, preset.id))
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-4",
				children: def.params.map((param) => {
					const value = part.params[param.key] ?? param.value;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium text-muted",
								children: paramLabel(param, lang)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs tabular-nums text-fg",
								children: [param.unit === "count" ? Math.round(value) : value.toFixed(param.step < 1 ? 1 : 0), param.unit === "mm" ? " mm" : ""]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: param.min,
							max: param.max,
							step: param.step,
							value: [value],
							onValueChange: ([v]) => {
								if (v === void 0) return;
								updateParams(part.id, { [param.key]: v });
							}
						})]
					}, param.key);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium text-muted",
					children: t(lang, "material")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-4 gap-2",
					children: MATERIAL_IDS.map((id) => {
						const m = MATERIALS[id];
						const active = part.material === id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							title: lang === "fa" ? m.labelFa : m.labelEn,
							onClick: () => setMaterial(part.id, id),
							className: cn("flex min-h-11 flex-col items-center gap-1 rounded-md p-1.5", active ? "shadow-[0_0_0_1px_var(--color-accent)]" : "shadow-[0_0_0_1px_rgba(255,255,255,0.08)]"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "size-6 rounded-full",
								style: { background: m.color },
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs leading-tight text-muted",
								children: lang === "fa" ? m.labelFa : m.labelEn
							})]
						}, id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VecEditor, {
				label: t(lang, "transform"),
				value: part.position,
				onChange: (position) => setTransform(part.id, position, part.rotation)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VecEditor, {
				label: t(lang, "rot"),
				value: part.rotation,
				onChange: (rotation) => setTransform(part.id, part.position, rotation)
			})
		]
	});
}
function VecEditor({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-medium text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-3 gap-2",
			children: [
				"X",
				"Y",
				"Z"
			].map((axis, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex flex-col gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-faint",
					children: axis
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "number",
					className: "h-10 px-2",
					value: Number(value[i].toFixed(1)),
					onChange: (e) => {
						const next = [...value];
						next[i] = Number(e.target.value);
						onChange(next);
					}
				})]
			}, axis))
		})]
	});
}
function ViewPanel() {
	const lang = useCadStore((s) => s.lang);
	const tool = useCadStore((s) => s.tool);
	const setTool = useCadStore((s) => s.setTool);
	const grid = useCadStore((s) => s.grid);
	const snap = useCadStore((s) => s.snap);
	const section = useCadStore((s) => s.section);
	const explode = useCadStore((s) => s.explode);
	const toggleGrid = useCadStore((s) => s.toggleGrid);
	const toggleSnap = useCadStore((s) => s.toggleSnap);
	const toggleSection = useCadStore((s) => s.toggleSection);
	const setExplode = useCadStore((s) => s.setExplode);
	const requestView = useCadStore((s) => s.requestView);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					{
						id: "select",
						icon: MousePointer2,
						label: "select"
					},
					{
						id: "move",
						icon: Move,
						label: "move"
					},
					{
						id: "rotate",
						icon: RotateCcw,
						label: "rotate"
					}
				].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: tool === item.id ? "default" : "secondary",
					onClick: () => setTool(item.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {}), t(lang, item.label)]
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					{
						id: "iso",
						label: "iso"
					},
					{
						id: "front",
						label: "front"
					},
					{
						id: "top",
						label: "top"
					},
					{
						id: "right",
						label: "right"
					},
					{
						id: "left",
						label: "left"
					},
					{
						id: "fit",
						label: "fit"
					}
				].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => requestView(item.id),
					children: [item.id === "fit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, {}) : null, t(lang, item.label)]
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleChip, {
						active: grid,
						onClick: toggleGrid,
						icon: Grid3x3,
						label: t(lang, "grid")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleChip, {
						active: snap,
						onClick: toggleSnap,
						icon: Magnet,
						label: t(lang, "snap")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleChip, {
						active: section,
						onClick: toggleSection,
						icon: Scan,
						label: t(lang, "section")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2 text-xs font-medium text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquareDashed, { className: "size-3.5" }), t(lang, "explode")]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs tabular-nums text-fg",
						children: [Math.round(explode * 100), "%"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 0,
					max: 1,
					step: .01,
					value: [explode],
					onValueChange: ([v]) => setExplode(v ?? 0)
				})]
			})
		]
	});
}
function ToggleChip({ active, onClick, icon: Icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("flex min-h-11 flex-col items-center justify-center gap-1 rounded-md text-xs", active ? "bg-accent text-accent-fg" : "bg-surface-2 text-fg"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), label]
	});
}
var _c = new Vector3();
function buildPart(kind, params) {
	switch (kind) {
		case "hex-bolt": return hexBolt(params);
		case "hex-nut": return hexNut(params);
		case "washer": return washer(params);
		case "standoff": return standoff(params);
		case "shaft": return shaft(params);
		case "block": return block(params);
		case "plate": return plate(params);
		case "pipe": return pipe(params);
		case "hex-bar": return hexBar(params);
		case "angle-bar": return angleBar(params);
		case "l-bracket": return lBracket(params);
		case "flange": return flange(params);
		case "spur-gear": return spurGear(params);
		case "bearing": return bearing(params);
		case "pulley": return pulley(params);
		case "coupling": return coupling(params);
		case "spring": return spring(params);
		default: return block({
			w: 20,
			h: 20,
			d: 20
		});
	}
}
function hexBolt(p) {
	const d = n(p.d, 8);
	const L = n(p.L, 32);
	const af = n(p.af, 13);
	const headH = n(p.headH, 5.3);
	const thread = Math.min(n(p.thread, 22), L);
	const shank = Math.max(.6, L - thread);
	const rHex = afToR(af);
	const r = d / 2;
	const tipH = Math.min(d * .32, 2.4);
	const tip = new ConeGeometry(r * .86, tipH, 20);
	tip.translate(0, tipH / 2, 0);
	const threadGeo = latheThread(r * .86, r, thread, Math.max(.65, d * .125));
	threadGeo.translate(0, tipH * .72, 0);
	const shankGeo = new CylinderGeometry(r, r, shank, 28);
	shankGeo.translate(0, tipH * .72 + thread + shank / 2, 0);
	const faceH = Math.min(.55, headH * .14);
	const face = new CylinderGeometry(d * .72, d * .72, faceH, 28);
	const yFace = tipH * .72 + thread + shank + faceH / 2;
	face.translate(0, yFace, 0);
	const head = new CylinderGeometry(rHex, rHex, headH, 6);
	head.translate(0, yFace + faceH / 2 + headH / 2, 0);
	const ch = Math.min(.75, headH * .22);
	const chamfer = new CylinderGeometry(rHex * .78, rHex, ch, 6);
	chamfer.translate(0, yFace + faceH / 2 + headH - ch / 2 + .02, 0);
	return solids([mergeAndCenter([
		tip,
		threadGeo,
		shankGeo,
		face,
		head,
		chamfer
	])]);
}
function hexNut(p) {
	const d = n(p.d, 8);
	const af = n(p.af, 13);
	const t = n(p.t, 6.5);
	const shape = hexShape(afToR(af));
	punch(shape, 0, 0, d / 2);
	return solids([center(extrude(shape, t, .18))]);
}
function washer(p) {
	const inner = n(p.d, 8.4);
	const od = Math.max(n(p.od, 16), inner + 1);
	const t = n(p.t, 1.6);
	return solids([center(extrude(ring(od / 2, inner / 2), t, 0))]);
}
function standoff(p) {
	const d = n(p.d, 6);
	const af = n(p.af, 10);
	const L = n(p.L, 20);
	const pin = L * .28;
	const body = new CylinderGeometry(afToR(af), afToR(af), L, 6);
	const p1 = new CylinderGeometry(d / 2, d / 2, pin, 20);
	const p2 = p1.clone();
	p1.translate(0, L / 2 + pin / 2, 0);
	p2.translate(0, -(L / 2 + pin / 2), 0);
	return solids([center(mergeAndCenter([
		body,
		p1,
		p2
	]))]);
}
function shaft(p) {
	const d = n(p.d, 16);
	const L = n(p.L, 90);
	const ch = Math.min(d * .12, 1.6);
	const body = new CylinderGeometry(d / 2, d / 2, L - ch * 2, 36);
	const c1 = new CylinderGeometry(d / 2 * .86, d / 2, ch, 36);
	const c2 = new CylinderGeometry(d / 2, d / 2 * .86, ch, 36);
	c1.translate(0, (L - ch) / 2, 0);
	c2.translate(0, -(L - ch) / 2, 0);
	return solids([mergeAndCenter([
		body,
		c1,
		c2
	])]);
}
function block(p) {
	const w = n(p.w, 40);
	const h = n(p.h, 24);
	const d = n(p.d, 30);
	return solids([new BoxGeometry(w, h, d)]);
}
function plate(p) {
	const w = n(p.w, 120);
	const d = n(p.d, 80);
	const t = n(p.t, 8);
	const hole = n(p.hole, 6.6);
	const m = n(p.margin, 12);
	const shape = new Shape();
	const hw = w / 2;
	const hd = d / 2;
	const r = Math.min(3, t);
	roundedRect(shape, -hw, -hd, w, d, r);
	if (hole > 0) {
		const xs = [-(hw - m), hw - m];
		const zs = [-(hd - m), hd - m];
		for (const x of xs) for (const z of zs) punch(shape, x, z, hole / 2);
	}
	return solids([center(extrude(shape, t, .12))]);
}
function pipe(p) {
	const od = n(p.od, 32);
	const id = Math.min(n(p.id, 26), od - .8);
	const L = n(p.L, 70);
	return solids([center(extrude(ring(od / 2, Math.max(.4, id / 2)), L, 0))]);
}
function hexBar(p) {
	const af = n(p.af, 14);
	const L = n(p.L, 60);
	return solids([new CylinderGeometry(afToR(af), afToR(af), L, 6)]);
}
function angleBar(p) {
	const a = n(p.a, 30);
	const b = n(p.b, 30);
	const t = n(p.t, 3);
	const L = n(p.L, 90);
	const shape = new Shape();
	shape.moveTo(0, 0);
	shape.lineTo(a, 0);
	shape.lineTo(a, t);
	shape.lineTo(t, t);
	shape.lineTo(t, b);
	shape.lineTo(0, b);
	shape.closePath();
	return solids([center(extrude(shape, L, 0))]);
}
function lBracket(p) {
	const a = n(p.a, 48);
	const b = n(p.b, 40);
	const w = n(p.w, 28);
	const t = n(p.t, 4);
	const hole = n(p.hole, 5);
	const shape = new Shape();
	shape.moveTo(0, 0);
	shape.lineTo(a, 0);
	shape.lineTo(a, t);
	shape.lineTo(t, t);
	shape.lineTo(t, b);
	shape.lineTo(0, b);
	shape.closePath();
	if (hole > 0) {
		punch(shape, a * .62, t * .5, hole / 2);
		punch(shape, t * .5, b * .62, hole / 2);
	}
	return solids([center(extrude(shape, w, .1))]);
}
function flange(p) {
	const od = n(p.od, 76);
	const id = n(p.id, 18);
	const t = n(p.t, 10);
	const bolts = Math.max(3, Math.round(n(p.bolts, 4)));
	const hole = n(p.hole, 7);
	const pcd = n(p.pcd, 52);
	const shape = ring(od / 2, Math.max(.6, id / 2));
	for (let i = 0; i < bolts; i++) {
		const a = i / bolts * Math.PI * 2;
		punch(shape, Math.cos(a) * (pcd / 2), Math.sin(a) * (pcd / 2), hole / 2);
	}
	const plateGeo = extrude(shape, t, .12);
	const hubH = t * .55;
	const hub = new CylinderGeometry(id / 2 + 4, id / 2 + 5.5, hubH, 36);
	const hubHole = new CylinderGeometry(id / 2, id / 2, hubH + .4, 32);
	hub.translate(0, t + hubH / 2, 0);
	hubHole.translate(0, t + hubH / 2, 0);
	const hubGeo = extrude(ring(id / 2 + 5.2, id / 2), hubH, 0);
	hubGeo.translate(0, t, 0);
	hub.dispose();
	hubHole.dispose();
	return solids([center(mergeAndCenter([plateGeo, hubGeo]))]);
}
function spurGear(p) {
	const teeth = Math.max(8, Math.round(n(p.teeth, 18)));
	const module = n(p.module, 2.5);
	const thickness = n(p.thickness, 10);
	const bore = n(p.bore, 12);
	const pitchR = teeth * module / 2;
	const outerR = pitchR + module;
	const rootR = Math.max(pitchR - module * 1.25, bore / 2 + module * .35);
	const shape = new Shape();
	const pts = [];
	for (let i = 0; i < teeth; i++) {
		const a = i / teeth * Math.PI * 2;
		const half = Math.PI / teeth;
		pts.push(polar(rootR, a - half * .92));
		pts.push(polar(rootR, a - half * .38));
		pts.push(polar(outerR, a - half * .18));
		pts.push(polar(outerR, a + half * .18));
		pts.push(polar(rootR, a + half * .38));
		pts.push(polar(rootR, a + half * .92));
	}
	shape.setFromPoints(pts);
	shape.closePath();
	punch(shape, 0, 0, bore / 2);
	return solids([center(mergeAndCenter([extrude(shape, thickness, .22), extrude(ring(bore / 2 + module * 1.1, bore / 2), thickness * 1.18, 0)]))]);
}
function bearing(p) {
	const od = n(p.od, 35);
	const id = n(p.id, 15);
	const w = n(p.w, 11);
	const race = Math.max(1.2, (od - id) * .18);
	const rings = center(mergeAndCenter([extrude(ring(od / 2, od / 2 - race), w, .08), extrude(ring(id / 2 + race, id / 2), w, .08)]));
	const ballR = Math.max(.8, (od - id) / 4 - .6);
	const pathR = (od + id) / 4;
	const count = Math.max(6, Math.round(Math.PI * 2 * pathR / (ballR * 2.35)));
	const ballGeos = [];
	for (let i = 0; i < count; i++) {
		const a = i / count * Math.PI * 2;
		const s = new SphereGeometry(ballR, 14, 10);
		s.translate(Math.cos(a) * pathR, 0, Math.sin(a) * pathR);
		ballGeos.push(s);
	}
	const balls = center(mergeAndCenter(ballGeos));
	rings.computeBoundingBox();
	balls.computeBoundingBox();
	return {
		meshes: [{
			geometry: rings,
			role: "body"
		}, {
			geometry: balls,
			role: "accent"
		}],
		dispose() {
			rings.dispose();
			balls.dispose();
		}
	};
}
function pulley(p) {
	const od = n(p.od, 44);
	const w = n(p.w, 14);
	const groove = Math.min(n(p.groove, 5), w * .7);
	const bore = n(p.bore, 10);
	const r = od / 2;
	const pts = [
		new Vector2(bore / 2, 0),
		new Vector2(r, 0),
		new Vector2(r, (w - groove) / 2),
		new Vector2(r - groove * .7, w / 2),
		new Vector2(r, (w + groove) / 2),
		new Vector2(r, w),
		new Vector2(bore / 2, w)
	];
	const geo = new LatheGeometry(pts, 48);
	geo.computeVertexNormals();
	return solids([center(geo)]);
}
function coupling(p) {
	const od = n(p.od, 28);
	const L = n(p.L, 32);
	const bore = n(p.bore, 10);
	const body = extrude(ring(od / 2, bore / 2), L, .15);
	const collar = extrude(ring(od / 2 + 1.2, bore / 2), 3.2, 0);
	collar.translate(0, L / 2 - 1.6, 0);
	const screw = new CylinderGeometry(1.6, 1.6, od / 2, 12);
	screw.rotateZ(Math.PI / 2);
	screw.translate(od / 4, L * .28, 0);
	const screw2 = screw.clone();
	screw2.translate(0, L * .44, 0);
	return solids([center(mergeAndCenter([
		body,
		collar,
		screw,
		screw2
	]))]);
}
function spring(p) {
	const d = n(p.d, 16);
	const wire = n(p.wire, 2);
	const L = n(p.L, 36);
	const coils = Math.max(3, Math.round(n(p.coils, 8)));
	const r = d / 2 - wire / 2;
	const pts = [];
	const steps = coils * 24;
	for (let i = 0; i <= steps; i++) {
		const t = i / 24;
		const a = t * Math.PI * 2;
		pts.push(new Vector3(Math.cos(a) * r, t / coils * L, Math.sin(a) * r));
	}
	const curve = new CatmullRomCurve3(pts);
	const geo = new TubeGeometry(curve, steps, wire / 2, 8, false);
	geo.computeVertexNormals();
	return solids([center(geo)]);
}
function solids(geos) {
	return {
		meshes: geos.map((geometry) => ({
			geometry,
			role: "body"
		})),
		dispose() {
			for (const g of geos) g.dispose();
		}
	};
}
function mergeAndCenter(geos) {
	const ready = geos.map((g) => {
		g.computeVertexNormals();
		return g;
	});
	const merged = mergeGeometries(ready, false);
	for (const g of ready) g.dispose();
	if (!merged) return new BoxGeometry(8, 8, 8);
	merged.computeVertexNormals();
	return center(merged);
}
function center(geo) {
	geo.computeBoundingBox();
	const b = geo.boundingBox;
	if (!b) return geo;
	b.getCenter(_c);
	geo.translate(-_c.x, -_c.y, -_c.z);
	return geo;
}
function extrude(shape, depth, bevel = 0) {
	const geo = new ExtrudeGeometry(shape, {
		depth,
		bevelEnabled: bevel > 0,
		bevelThickness: bevel,
		bevelSize: bevel,
		bevelSegments: 1,
		curveSegments: 20
	});
	geo.rotateX(-Math.PI / 2);
	geo.computeVertexNormals();
	return geo;
}
function hexShape(vertexR) {
	const s = new Shape();
	for (let i = 0; i < 6; i++) {
		const a = Math.PI / 6 + i * Math.PI / 3;
		const x = Math.cos(a) * vertexR;
		const y = Math.sin(a) * vertexR;
		if (i === 0) s.moveTo(x, y);
		else s.lineTo(x, y);
	}
	s.closePath();
	return s;
}
function ring(outer, inner) {
	const s = new Shape();
	s.absarc(0, 0, Math.max(outer, inner + .2), 0, Math.PI * 2, false);
	punch(s, 0, 0, inner);
	return s;
}
function punch(shape, x, y, r) {
	if (r <= .05) return;
	const hole = new Path();
	hole.absarc(x, y, r, 0, Math.PI * 2, true);
	shape.holes.push(hole);
}
function roundedRect(shape, x, y, w, h, r) {
	const rr = Math.min(r, w / 4, h / 4);
	shape.moveTo(x + rr, y);
	shape.lineTo(x + w - rr, y);
	shape.quadraticCurveTo(x + w, y, x + w, y + rr);
	shape.lineTo(x + w, y + h - rr);
	shape.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
	shape.lineTo(x + rr, y + h);
	shape.quadraticCurveTo(x, y + h, x, y + h - rr);
	shape.lineTo(x, y + rr);
	shape.quadraticCurveTo(x, y, x + rr, y);
}
function latheThread(rIn, rOut, length, pitch) {
	const pts = [];
	const steps = Math.max(3, Math.floor(length / pitch)) * 2;
	pts.push(new Vector2(rIn * .9, 0));
	for (let i = 0; i <= steps; i++) {
		const y = i / steps * length;
		pts.push(new Vector2(i % 2 === 0 ? rOut : rIn, y));
	}
	pts.push(new Vector2(rIn * .9, length));
	const geo = new LatheGeometry(pts, 28);
	geo.computeVertexNormals();
	return geo;
}
function polar(r, a) {
	return new Vector2(Math.cos(a) * r, Math.sin(a) * r);
}
function afToR(af) {
	return af / Math.sqrt(3);
}
function n(v, fallback) {
	return Number.isFinite(v) ? v : fallback;
}
var DEG = Math.PI / 180;
var TARGET = [
	0,
	34,
	0
];
var PRESETS = {
	iso: [
		150,
		118,
		168
	],
	front: [
		0,
		52,
		230
	],
	top: [
		0,
		280,
		.2
	],
	right: [
		230,
		52,
		0
	],
	left: [
		-230,
		52,
		0
	]
};
var clipPlane = new Plane(new Vector3(-1, 0, 0), 0);
function Viewport() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 touch-none bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Canvas, {
			shadows: true,
			dpr: [1, 1.75],
			camera: {
				position: PRESETS.iso,
				fov: 40,
				near: .5,
				far: 2500
			},
			gl: {
				antialias: true,
				preserveDrawingBuffer: true,
				localClippingEnabled: true,
				alpha: false
			},
			onPointerMissed: () => useCadStore.getState().select(null),
			onCreated: ({ gl }) => {
				gl.setClearColor(SCENE.clear, 1);
				gl.toneMapping = 4;
				gl.toneMappingExposure = 1.08;
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SceneLights, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SceneGrid, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Parts, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraControls, {
					makeDefault: true,
					smoothTime: .22,
					minDistance: 24,
					maxDistance: 900,
					draggingSmoothTime: .12
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraRig, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CaptureRig, {})
			]
		})
	});
}
function SceneLights() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hemisphereLight", { args: [
			SCENE.hemiSky,
			SCENE.hemiGround,
			.52
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ambientLight", { intensity: .16 }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("directionalLight", {
			position: [
				130,
				190,
				90
			],
			intensity: 1.32,
			castShadow: true,
			"shadow-mapSize": [1024, 1024],
			"shadow-camera-near": 20,
			"shadow-camera-far": 640,
			"shadow-camera-left": -180,
			"shadow-camera-right": 180,
			"shadow-camera-top": 180,
			"shadow-camera-bottom": -180,
			color: SCENE.key
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("directionalLight", {
			position: [
				-100,
				70,
				-80
			],
			intensity: .32,
			color: SCENE.fill
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("directionalLight", {
			position: [
				40,
				50,
				140
			],
			intensity: .18,
			color: SCENE.rim
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactShadows, {
			opacity: .42,
			scale: 420,
			blur: 2.1,
			far: 90,
			position: [
				0,
				0,
				0
			]
		})
	] });
}
function SceneGrid() {
	if (!useCadStore((s) => s.grid)) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Grid, {
		position: [
			0,
			.02,
			0
		],
		args: [1, 1],
		cellSize: 10,
		cellThickness: .55,
		cellColor: SCENE.gridCell,
		sectionSize: 50,
		sectionThickness: 1.05,
		sectionColor: SCENE.gridSection,
		fadeDistance: 520,
		fadeStrength: 1.15,
		infiniteGrid: true
	});
}
function Parts() {
	const parts = useCadStore((s) => s.parts);
	const selectedId = useCadStore((s) => s.selectedId);
	const explode = useCadStore((s) => s.explode);
	const section = useCadStore((s) => s.section);
	const tool = useCadStore((s) => s.tool);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: parts.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartInstance, {
		part,
		selected: part.id === selectedId,
		explode,
		section,
		tool
	}, part.id)) });
}
function PartInstance({ part, selected, explode, section, tool }) {
	const group = (0, import_react.useRef)(null);
	const dragging = (0, import_react.useRef)(false);
	const [gizmoReady, setGizmoReady] = (0, import_react.useState)(false);
	const select = useCadStore((s) => s.select);
	const setTransform = useCadStore((s) => s.setTransform);
	const controls = useThree((s) => s.controls);
	const pos = (0, import_react.useMemo)(() => explodedPos(part.position, explode), [part.position, explode]);
	const rot = part.rotation;
	(0, import_react.useLayoutEffect)(() => {
		if (group.current) setGizmoReady(true);
	}, []);
	(0, import_react.useLayoutEffect)(() => {
		if (!group.current || dragging.current) return;
		group.current.position.set(pos[0], pos[1], pos[2]);
		group.current.rotation.set(rot[0] * DEG, rot[1] * DEG, rot[2] * DEG);
	}, [pos, rot]);
	const showGizmo = selected && !part.locked && explode < .02 && (tool === "move" || tool === "rotate") && gizmoReady;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
		ref: group,
		visible: part.visible,
		onPointerDown: (e) => {
			e.stopPropagation();
			select(part.id);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartMeshes, {
			part,
			selected,
			section
		})
	}), showGizmo && group.current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransformControls, {
		object: group.current,
		mode: tool === "rotate" ? "rotate" : "translate",
		size: .85,
		space: "world",
		onMouseDown: () => {
			dragging.current = true;
			if (controls) controls.enabled = false;
		},
		onMouseUp: () => {
			dragging.current = false;
			if (controls) controls.enabled = true;
			const g = group.current;
			if (!g) return;
			const step = useCadStore.getState().snap ? useCadStore.getState().snapStep : 0;
			let nextPos = [
				g.position.x,
				g.position.y,
				g.position.z
			];
			let nextRot = [
				g.rotation.x / DEG,
				g.rotation.y / DEG,
				g.rotation.z / DEG
			];
			if (step && tool === "move") {
				nextPos = nextPos.map((v) => Math.round(v / step) * step);
				g.position.set(...nextPos);
			}
			if (step && tool === "rotate") {
				nextRot = nextRot.map((v) => Math.round(v / 15) * 15);
				g.rotation.set(nextRot[0] * DEG, nextRot[1] * DEG, nextRot[2] * DEG);
			}
			setTransform(part.id, nextPos, nextRot);
		}
	}) : null] });
}
function PartMeshes({ part, selected, section }) {
	const key = JSON.stringify(part.params);
	const built = (0, import_react.useMemo)(() => buildPart(part.kind, part.params), [part.kind, key]);
	(0, import_react.useEffect)(() => () => built.dispose(), [built]);
	const look = MATERIALS[part.material];
	const planes = section ? [clipPlane] : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: built.meshes.map((mesh, i) => {
		const accent = mesh.role === "accent";
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			geometry: mesh.geometry,
			castShadow: true,
			receiveShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: accent ? MATERIALS.stainless.color : look.color,
				metalness: accent ? .95 : look.metalness,
				roughness: accent ? .16 : look.roughness,
				emissive: selected ? "#9aadc0" : "#000000",
				emissiveIntensity: selected ? .14 : 0,
				clippingPlanes: planes,
				clipShadows: true
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Edges, {
				threshold: 24,
				color: selected ? SCENE.edgeSelected : SCENE.edge
			})]
		}, i);
	}) });
}
function CameraRig() {
	const viewTick = useCadStore((s) => s.viewTick);
	const parts = useCadStore((s) => s.parts);
	const clearView = useCadStore((s) => s.clearView);
	const controls = useThree((s) => s.controls);
	(0, import_react.useEffect)(() => {
		if (!viewTick || !controls) return;
		const run = async () => {
			if (viewTick === "fit") {
				const box = new Box3();
				for (const p of parts) box.expandByPoint(new Vector3(...p.position));
				if (box.isEmpty()) await controls.setLookAt(150, 118, 168, TARGET[0], TARGET[1], TARGET[2], true);
				else {
					box.expandByScalar(55);
					await controls.fitToBox(box, true);
				}
			} else {
				const eye = PRESETS[viewTick] ?? PRESETS.iso;
				await controls.setLookAt(eye[0], eye[1], eye[2], TARGET[0], TARGET[1], TARGET[2], true);
			}
			clearView();
		};
		run();
	}, [
		viewTick,
		controls,
		parts,
		clearView
	]);
	return null;
}
function CaptureRig() {
	const tick = useCadStore((s) => s.captureTick);
	const gl = useThree((s) => s.gl);
	const scene = useThree((s) => s.scene);
	const camera = useThree((s) => s.camera);
	const prev = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		if (!tick || tick === prev.current) return;
		prev.current = tick;
		gl.render(scene, camera);
		const link = document.createElement("a");
		link.href = gl.domElement.toDataURL("image/png");
		link.download = "alyazh.png";
		link.click();
	}, [
		tick,
		gl,
		scene,
		camera
	]);
	return null;
}
function explodedPos(pos, explode) {
	if (explode <= .002) return pos;
	const len = Math.hypot(pos[0], pos[2]);
	const nx = len > .01 ? pos[0] / len : 0;
	const nz = len > .01 ? pos[2] / len : 0;
	const k = explode * 38;
	return [
		pos[0] + nx * k,
		pos[1] + explode * 10,
		pos[2] + nz * k
	];
}
function BottomSheet({ open, onOpenChange, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Root, {
		open,
		onOpenChange,
		shouldScaleBackground: false,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Portal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Overlay, { className: "fixed inset-0 z-50 bg-bg/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Content, {
			className: cn("fixed inset-x-0 bottom-0 z-50 flex max-h-[78dvh] flex-col rounded-t-xl bg-surface", "shadow-[0_0_0_1px_rgba(255,255,255,0.08)]"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-3 h-1 w-10 rounded-full bg-border" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Title, {
					className: "px-5 pb-2 pt-3 text-sm font-medium text-fg",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-h-0 flex-1 overflow-y-auto px-4 pb-[calc(1.25rem+env(safe-area-inset-bottom))]",
					children
				})
			]
		})] })
	});
}
function AppShell() {
	const lang = useCadStore((s) => s.lang);
	const panel = useCadStore((s) => s.panel);
	const setPanel = useCadStore((s) => s.setPanel);
	const desktop = useDesktop();
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = lang;
		document.documentElement.dir = lang === "fa" ? "rtl" : "ltr";
	}, [lang]);
	useHotkeys();
	const sheetOpen = !desktop && panel !== "none";
	const sheetTitle = panel === "library" ? t(lang, "library") : panel === "parts" ? t(lang, "parts") : panel === "view" ? t(lang, "view") : panel === "project" ? t(lang, "project") : t(lang, "properties");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex h-dvh flex-col overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex min-h-0 flex-1",
				children: [
					desktop ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "flex w-72 shrink-0 flex-col gap-3 overflow-y-auto border-e border-border bg-surface p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium",
							children: t(lang, "library")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LibraryPanel, {})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
						className: "relative min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Viewport, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyHint, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewChipBar, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectedBar, {}),
							!desktop ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setPanel("library"),
								className: "absolute end-4 bottom-4 z-20 flex size-14 items-center justify-center rounded-lg bg-accent text-accent-fg shadow-lg",
								"aria-label": t(lang, "add"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-6" })
							}) : null
						]
					}),
					desktop ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "flex w-80 shrink-0 flex-col overflow-hidden border-s border-border bg-surface",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-h-0 flex-1 overflow-y-auto p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mb-3 text-sm font-medium",
								children: t(lang, "properties")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PropertiesPanel, {})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-h-[42%] overflow-y-auto border-t border-border p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mb-3 text-sm font-medium",
								children: t(lang, "parts")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartsPanel, {})]
						})]
					}) : null
				]
			}),
			desktop ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "flex h-12 items-center justify-between gap-3 border-t border-border bg-surface px-4 text-xs text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: t(lang, "units")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DesktopTools, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "tagline") })
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BottomSheet, {
				open: sheetOpen,
				onOpenChange: (open) => {
					if (!open) setPanel("none");
				},
				title: sheetTitle,
				children: [
					panel === "library" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LibraryPanel, {}) : null,
					panel === "parts" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartsPanel, {}) : null,
					panel === "view" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewPanel, {}) : null,
					panel === "project" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectPanel, {}) : null,
					panel === "props" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PropertiesPanel, {}) : null
				]
			})
		]
	});
}
function TopBar() {
	const lang = useCadStore((s) => s.lang);
	const name = useCadStore((s) => s.name);
	const parts = useCadStore((s) => s.parts);
	const undo = useCadStore((s) => s.undo);
	const redo = useCadStore((s) => s.redo);
	const past = useCadStore((s) => s.past);
	const future = useCadStore((s) => s.future);
	const setPanel = useCadStore((s) => s.setPanel);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex h-14 shrink-0 items-center gap-2 border-b border-border bg-surface px-3 pt-[env(safe-area-inset-top)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "truncate text-sm font-medium tracking-tight text-fg",
						children: t(lang, "app")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "truncate text-xs text-muted",
						children: [
							name,
							" · ",
							parts.length,
							" ",
							t(lang, "partsCount")
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon-sm",
				onClick: undo,
				disabled: past.length === 0,
				"aria-label": t(lang, "undo"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon-sm",
				onClick: redo,
				disabled: future.length === 0,
				"aria-label": t(lang, "redo"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Redo2, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon-sm",
				onClick: () => setPanel("project"),
				"aria-label": t(lang, "project"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderCog, {})
			})
		]
	});
}
function Mark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "grid size-9 place-items-center rounded-md bg-surface-2 text-accent shadow-[0_0_0_1px_rgba(255,255,255,0.08)]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 24 24",
			className: "size-5",
			"aria-hidden": true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "12,3 20,7.5 20,16.5 12,21 4,16.5 4,7.5",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.6"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "3",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.6"
			})]
		})
	});
}
function ViewChipBar() {
	const lang = useCadStore((s) => s.lang);
	const requestView = useCadStore((s) => s.requestView);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none absolute inset-x-3 top-3 z-10 flex justify-end",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-auto flex gap-1 rounded-lg bg-surface/90 p-1 shadow-[0_0_0_1px_rgba(255,255,255,0.08)]",
			children: [
				"iso",
				"front",
				"top",
				"fit"
			].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => requestView(id),
				className: "h-9 min-w-11 rounded-sm px-2.5 text-xs text-fg hover:bg-surface-2",
				children: t(lang, id)
			}, id))
		})
	});
}
function SelectedBar() {
	const lang = useCadStore((s) => s.lang);
	const parts = useCadStore((s) => s.parts);
	const selectedId = useCadStore((s) => s.selectedId);
	const tool = useCadStore((s) => s.tool);
	const setTool = useCadStore((s) => s.setTool);
	const setPanel = useCadStore((s) => s.setPanel);
	const duplicateSelected = useCadStore((s) => s.duplicateSelected);
	const deleteSelected = useCadStore((s) => s.deleteSelected);
	const part = parts.find((p) => p.id === selectedId);
	if (!part) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-x-3 bottom-20 z-10 flex items-center gap-1 rounded-lg bg-surface/95 p-1 shadow-[0_0_0_1px_rgba(255,255,255,0.08)] lg:bottom-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setPanel("props"),
				className: "min-h-11 min-w-0 flex-1 truncate px-3 text-start text-sm text-fg",
				children: part.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
				active: tool === "select",
				label: t(lang, "select"),
				onClick: () => setTool("select"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MousePointer2, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
				active: tool === "move",
				label: t(lang, "move"),
				onClick: () => setTool("move"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Move, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
				active: tool === "rotate",
				label: t(lang, "rotate"),
				onClick: () => setTool("rotate"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
				label: t(lang, "duplicate"),
				onClick: duplicateSelected,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
				label: t(lang, "delete"),
				onClick: deleteSelected,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
			})
		]
	});
}
function ToolBtn({ active, label, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		onClick,
		className: cn("grid size-11 place-items-center rounded-sm", active ? "bg-accent text-accent-fg" : "text-fg hover:bg-surface-2"),
		children
	});
}
function EmptyHint() {
	const lang = useCadStore((s) => s.lang);
	const parts = useCadStore((s) => s.parts);
	const setPanel = useCadStore((s) => s.setPanel);
	const loadSample = useCadStore((s) => s.loadSample);
	if (parts.length > 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none absolute inset-0 z-10 grid place-items-center p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto max-w-sm rounded-xl bg-surface p-6 text-center shadow-[0_0_0_1px_rgba(255,255,255,0.08)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-lg font-medium tracking-tight text-fg",
					children: t(lang, "emptyTitle")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-normal text-muted",
					children: t(lang, "emptyBody")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-col gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => setPanel("library"),
						children: t(lang, "add")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: loadSample,
						children: t(lang, "loadSample")
					})]
				})
			]
		})
	});
}
function MobileNav() {
	const lang = useCadStore((s) => s.lang);
	const panel = useCadStore((s) => s.panel);
	const setPanel = useCadStore((s) => s.setPanel);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "flex h-16 shrink-0 items-stretch border-t border-border bg-surface pb-[env(safe-area-inset-bottom)]",
		children: [
			{
				id: "library",
				icon: Library,
				label: "library"
			},
			{
				id: "parts",
				icon: Box,
				label: "parts"
			},
			{
				id: "view",
				icon: ScanEye,
				label: "view"
			},
			{
				id: "project",
				icon: FolderCog,
				label: "project"
			}
		].map((item) => {
			const active = panel === item.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setPanel(active ? "none" : item.id),
				className: cn("flex flex-1 flex-col items-center justify-center gap-1 text-xs", active ? "text-accent" : "text-muted"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-5" }), t(lang, item.label)]
			}, item.id);
		})
	});
}
function DesktopTools() {
	const lang = useCadStore((s) => s.lang);
	const tool = useCadStore((s) => s.tool);
	const setTool = useCadStore((s) => s.setTool);
	const grid = useCadStore((s) => s.grid);
	const snap = useCadStore((s) => s.snap);
	const section = useCadStore((s) => s.section);
	const toggleGrid = useCadStore((s) => s.toggleGrid);
	const toggleSnap = useCadStore((s) => s.toggleSnap);
	const toggleSection = useCadStore((s) => s.toggleSection);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: tool === "select" ? "default" : "ghost",
				onClick: () => setTool("select"),
				children: t(lang, "select")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: tool === "move" ? "default" : "ghost",
				onClick: () => setTool("move"),
				children: t(lang, "move")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: tool === "rotate" ? "default" : "ghost",
				onClick: () => setTool("rotate"),
				children: t(lang, "rotate")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: grid ? "secondary" : "ghost",
				onClick: toggleGrid,
				children: t(lang, "grid")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: snap ? "secondary" : "ghost",
				onClick: toggleSnap,
				children: t(lang, "snap")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: section ? "secondary" : "ghost",
				onClick: toggleSection,
				children: t(lang, "section")
			})
		]
	});
}
function useDesktop() {
	const [desktop, setDesktop] = (0, import_react.useState)(() => typeof window !== "undefined" ? window.matchMedia("(min-width: 1024px)").matches : false);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(min-width: 1024px)");
		const on = () => setDesktop(mq.matches);
		on();
		mq.addEventListener("change", on);
		return () => mq.removeEventListener("change", on);
	}, []);
	return desktop;
}
function useHotkeys() {
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA") return;
			const s = useCadStore.getState();
			if (e.key === "Delete" || e.key === "Backspace") s.deleteSelected();
			if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "z") {
				e.preventDefault();
				if (e.shiftKey) s.redo();
				else s.undo();
			}
			if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "d") {
				e.preventDefault();
				s.duplicateSelected();
			}
			if (e.key === "g" || e.key === "G") s.setTool("move");
			if (e.key === "r" || e.key === "R") s.setTool("rotate");
			if (e.key === "q" || e.key === "Q") s.setTool("select");
			if (e.key === "f" || e.key === "F") s.requestView("fit");
			if (e.key === "Escape") {
				s.select(null);
				s.setPanel("none");
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {});
}
//#endregion
export { Home as component };
