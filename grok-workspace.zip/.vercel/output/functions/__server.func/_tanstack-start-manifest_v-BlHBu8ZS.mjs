//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BlHBu8ZS.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-_Nsj6fKs.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-_Nsj6fKs.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-zNPe3bDI.js"]
	}
} });
//#endregion
export { tsrStartManifest };
